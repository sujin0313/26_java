package my.app;
import java.util.HashMap;
public class HashMapEx {

	public static void main(String[] args) {
		HashMap<String,Integer> hash=new HashMap<String,Integer>();
		hash.put("홍길동",70);
		hash.put("이길동",100);
		hash.put("김길동",50);
		hash.put("박길동",90);
		System.out.println(hash.get("이길동"));
	}

}
