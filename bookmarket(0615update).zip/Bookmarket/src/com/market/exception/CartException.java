// 장바구니 오류 처리 사용자 정의 예외 클래스
package com.market.exception;
public class CartException extends Exception {
		public CartException(String str) {
			super(str);
		}
}
