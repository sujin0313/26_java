package day14;

import java.awt.Component;
import java.awt.Container;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class MouseListenerEx2 extends JFrame {
    JLabel lb;

    public MouseListenerEx2() {
        Container con = getContentPane();
        con.setLayout(null);

        lb = new JLabel("hello");
        lb.setLocation(30, 30);
        lb.setSize(50, 20);
        con.add(lb);

        con.addMouseMotionListener(new MyMouseListener2());

        setSize(400, 400);
        setTitle(lb.getText());
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    class MyMouseListener2 extends MouseMotionAdapter {

        @Override
        public void mouseDragged(MouseEvent e) {
            
            lb.setText("MouseDragged("+e.getX()+","+e.getY()+")");
        }
    }

    public static void main(String[] args) {
    	 Component e;
		 lb.setText("MouseDragged("+e.getX()+","+e.getY()+")");
    }
}