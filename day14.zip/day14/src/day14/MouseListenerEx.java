package day14;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class MouseListenerEx extends JFrame {
	JLabel lb;
	public MouseListenerEx() {
		Container con=getContentPane();
		con.setLayout(new FlowLayout());
		lb=new JLabel("hello");
		lb.setLocation(30,30);
		lb.setSize(50,20);
		con.add(lb);
		con.addMouseListener(new MyMouseListener());
		setSize(400,400);
		setVisible(true);
		setTitle(lb.getText());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MouseListenerEx();
	}
	
	class MyMouseListener implements MouseListener{

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			int x=e.getX();
			int y=e.getY();
			lb.setLocation(x,y);
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	}

}
