package com.market.page;
//페이지 전체 오류로 AI 활용->틀 잡은 후 pdf 참고해서 완성
import javax.swing.*;

import com.market.bookitem.BookInIt;
import com.market.cart.Cart;

import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.market.member.UserInIt;

public class CartOrderBillPage extends JPanel {

    Cart mCart;
    JPanel shippingPanel;

    public CartOrderBillPage(JPanel panel, Cart cart) {

        setLayout(null);

        Rectangle rect = panel.getBounds();
        setPreferredSize(rect.getSize());

        this.mCart = cart;

        shippingPanel = new JPanel(null);
        //shippingPanel.setBounds(100, 50, 700, 500);
        shippingPanel.setBounds(0,0,700,500);
        shippingPanel.setLayout(null);
        panel.add(shippingPanel);
        printBillInfo(UserInIt.getmUser().getName(),String.valueOf(UserInIt.getmUser().getPhone()),UserInIt.getmUser().getAddr());

        printBillInfo(
                "입력된 고객 이름",
                "입력된 고객 연락처",
                "입력된 고객 배송지");
    }

    private void printBillInfo(String name, String phone, String address) {

        Font ft = new Font("함초롱돋움", Font.BOLD, 15);

        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        String strDate = formatter.format(date);

        JPanel titlePanel = new JPanel();
        titlePanel.setBounds(0, 0, 700, 40);

        JLabel titleLabel =
                new JLabel("---------------- 배송 받을 고객 정보 ----------------");

        titleLabel.setFont(ft);

        titlePanel.add(titleLabel);
        shippingPanel.add(titlePanel);

        JPanel infoPanel1 = new JPanel();
        infoPanel1.setBounds(0, 40, 700, 40);

        JLabel nameLabel =
                new JLabel("고객명 : " + name + "          연락처 : " + phone);

        nameLabel.setFont(ft);

        infoPanel1.add(nameLabel);
        shippingPanel.add(infoPanel1);

        JPanel infoPanel2 = new JPanel();
        infoPanel2.setBounds(0, 80, 700, 40);

        JLabel addressLabel =
                new JLabel("배송지 : " + address + "          발송일 : " + strDate);

        addressLabel.setFont(ft);

        infoPanel2.add(addressLabel);
        shippingPanel.add(infoPanel2);

        JPanel printPanel = new JPanel();
        printPanel.setBounds(0, 130, 700, 250);

        printCart(printPanel);

        shippingPanel.add(printPanel);
    }

    private void printCart(JPanel panel) {

        Font ft = new Font("함초롱돋움", Font.BOLD, 14);

        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel title =
                new JLabel("장바구니 상품 목록 : ------------------------------");

        title.setFont(ft);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel header =
                new JLabel("도서ID          |          수량          |          합계");

        header.setFont(ft);
        header.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel line =
                new JLabel("----------------------------------------------------");

        line.setFont(ft);
        line.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(title);
        panel.add(Box.createVerticalStrut(10));
        panel.add(header);
        panel.add(line);

        int sum = 0;

        for (int i = 0; i < mCart.mCartItem.size(); i++) {

            String row =
                    mCart.mCartItem.get(i).getBookID()
                            + "          |          "
                            + mCart.mCartItem.get(i).getQuantity()
                            + "          |          "
                            + mCart.mCartItem.get(i).getTotalPrice();

            JLabel itemLabel = new JLabel(row);

            itemLabel.setFont(ft);
            itemLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

            panel.add(itemLabel);

            sum += mCart.mCartItem.get(i).getTotalPrice();
        }

        panel.add(Box.createVerticalStrut(20));

        JLabel totalLabel =
                new JLabel("주문 총금액 : " + sum + "원");

        totalLabel.setFont(new Font("함초롱돋움", Font.BOLD, 16));
        totalLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(totalLabel);
    }

}