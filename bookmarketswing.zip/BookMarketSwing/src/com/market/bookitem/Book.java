// 도서 정보 관리 클래스(Item 클래스 상속)
package com.market.bookitem;

public class Book extends Item {
	//public static char[] getBookID;
	private String author;
	private String description;
	private String category;
	private String releaseDate;
	public Book(String bookId,String name,int unitPrice) {
		super(bookId,name,unitPrice);
		this.bookId=bookId;
	}
	public Book(String bookId,String name,int unitPrice,String author,String description,String category,String releaseDate) {
		super(bookId,name,unitPrice);
		this.author=author;
		this.description=description;
		this.category=category;
		this.releaseDate=releaseDate;
	}

	public String getAuthor() {
		return author;
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	@Override
	public String getBookId() {
		// TODO Auto-generated method stub
		return super.bookId;
	}
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	@Override
	public int getUnitPrice() {
		// TODO Auto-generated method stub
		return unitPrice;
	}
	@Override
	public void setBookId(String bookId) {
		this.bookId=bookId;
		
	}
	@Override
	public void setName(String name) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setUniPrice(String uniprice) {
		// TODO Auto-generated method stub
		
	}

}
