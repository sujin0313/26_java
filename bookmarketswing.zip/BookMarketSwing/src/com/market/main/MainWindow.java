package com.market.main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import com.market.page.GuestInfoPage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.market.cart.Cart;
import com.market.bookitem.BookInIt;
import com.market.page.CartAddItemPage;
import com.market.page.CartItemListPage;
import com.market.page.CartShippingPage;
import com.market.page.AdminLoginDialog;
import com.market.page.AdminPage;

public class MainWindow extends JFrame {
	static Cart mCart;
    static JPanel mMenuPanel, mPagePanel;

    public MainWindow(String title, int x, int y, int w, int h) {

        initContainer(title, x, y, w, h);
        initMenu();

        setVisible(true);
        setResizable(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setIconImage(
                new ImageIcon(
                        "/Users/sujin/eclipse-workspace/BookMarketSwing/src/images/shop.png")
                                .getImage());
    }

    private void initMenu() {
		Font ft;
		ft=new Font("함초롬돋움",Font.BOLD,15);
		JMenuBar menuBar=new JMenuBar();
		JMenu menu01=new JMenu("고객");
		menu01.setFont(ft);
		JMenuItem item01=new JMenuItem("고객 정보");
		JMenuItem item11=new JMenuItem("종료");
		menu01.add(item01);
		menu01.add(item11);
		menuBar.add(menu01);
		
		JMenu menu02=new JMenu("상품");
		menu02.setFont(ft);
		JMenuItem item02=new JMenuItem("상품 목록");
		menu02.add(item02);
		menuBar.add(menu02);
		
		JMenu menu03=new JMenu("장바구니");
		menu03.setFont(ft);
		JMenuItem item03=new JMenuItem("항목 추가");
		JMenuItem item04=new JMenuItem("항목 수량 줄이기");
		JMenuItem item05=new JMenuItem("항목 삭제하기");
		JMenuItem item06=new JMenuItem("장바구니 비우기");
		menu03.add(item03);
		menu03.add(item04);
		menu03.add(item05);
		menu03.add(item06);
		menuBar.add(menu03);
		
		JMenu menu04=new JMenu("주문");
		menu04.setFont(ft);
		JMenuItem item07=new JMenuItem("영수증 표시");
		menu04.add(item07);
		menuBar.add(menu04);
		setJMenuBar(menuBar);
		
		item01.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mPagePanel.removeAll();
				mPagePanel.add("고객 정보 확인",new GuestInfoPage(mPagePanel));
				add(mPagePanel);
				mPagePanel.revalidate();
			}
		});
		item02.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mPagePanel.removeAll();
				mPagePanel.add("장바구니에 항목 추가하기",new CartAddItemPage(mPagePanel,mCart));
				add(mPagePanel);
				mPagePanel.revalidate();
			}
		});
		item11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new GuestWindow("고객 정보 입력",0,0,1000,750);
				add(mPagePanel);
				mPagePanel.revalidate();
			}
		});
	}

	private void initContainer(String title, int x, int y, int w, int h) {

        setTitle(title);
        setBounds(x, y, w, h);

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((screenSize.width - w) / 2,
                    (screenSize.height - h) / 2);

        Container c = getContentPane();
        c.setLayout(new BorderLayout());

        mMenuPanel = new JPanel();
        mMenuPanel.setLayout(new GridLayout(0, 4, 10, 10));
        mMenuPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        mPagePanel = new JPanel();

        c.add(mMenuPanel, BorderLayout.NORTH);
        c.add(mPagePanel, BorderLayout.CENTER);

        menuIntroduction();
        this.addWindowListener(new WindowAdapter() {
        	public void windowClose(WindowEvent e) {
        		setVisible(false);
        		new GuestWindow("고객 정보 입력",0,0,1000,750);
        	}
        });
    }

    private ImageIcon resizeIcon(String path) {

        ImageIcon icon = new ImageIcon(path);

        Image img = icon.getImage();

        Image resizedImg =
                img.getScaledInstance(20, 20, Image.SCALE_SMOOTH);

        return new ImageIcon(resizedImg);
    }

    private void menuIntroduction() {
    	mCart=new Cart();

        Font ft = new Font("함초롱돋움", Font.BOLD, 12);

        JButton bt1 = new JButton(
                "고객 정보 확인하기",
                resizeIcon("/Users/sujin/eclipse-workspace/BookMarketSwing/src/images/1.png"));
        mMenuPanel.add(bt1);
        bt1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		mPagePanel.removeAll();
        		mPagePanel.add("고객 정보 확인",new GuestInfoPage(mPagePanel));
        		mPagePanel.revalidate();
        		mPagePanel.repaint();
        	}
        });
        JButton bt2 = new JButton(
                "장바구니 상품 목록 보기",
                resizeIcon("/Users/sujin/eclipse-workspace/BookMarketSwing/src/images/2.png"));
        bt2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(mCart.mCartCount==0) {
        			JOptionPane.showMessageDialog(bt2, "장바구니에 항목이 없습니다","장바구니 상품 목록 보기",JOptionPane.ERROR_MESSAGE);
        		}
        		else {
        			mPagePanel.removeAll();
        			mPagePanel.add("장바구니 상품 목록 보기",new CartItemListPage(mPagePanel,mCart));
        			mPagePanel.revalidate();
        			mPagePanel.repaint();
        		}
        	}
        });

        JButton bt3 = new JButton(
                "장바구니 비우기",
                resizeIcon("/Users/sujin/eclipse-workspace/BookMarketSwing/src/images/3.png"));
        bt3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(mCart.mCartCount==0) {
        			JOptionPane.showMessageDialog(bt3, "장바구니에 항목이 없습니다","장바구니 비우기",JOptionPane.ERROR_MESSAGE);
        		}
        		else {
        			mPagePanel.removeAll();
        			menuCartClear(bt3);
        			mPagePanel.add("장바구니 비우기",new CartItemListPage(mPagePanel,mCart));
        			mPagePanel.revalidate();
        			mPagePanel.repaint();
        		}
        	}
        	private void menuCartClear(JButton button) {
				if(mCart.mCartCount==0) {
					JOptionPane.showMessageDialog(button, "장바구니에 항목이 없습니다");
				}
				else {
					int select=JOptionPane.showConfirmDialog(button, "장바구니의 모든 항목을 삭제하겠습니까?");
					if(select==0) {
						mCart.deleteBook();
						JOptionPane.showMessageDialog(button, "장바구니의 모든 항목을 삭제했습니다");
					}
				}
			}
        });
       
    
        
        

        JButton bt4 = new JButton(
                "장바구니에 항목 추가하기",
                resizeIcon("/Users/sujin/eclipse-workspace/BookMarketSwing/src/images/4.png"));
        bt4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		mPagePanel.removeAll();
        		BookInIt.init();
        		mPagePanel.add("장바구니에 항목 추가하기",new CartAddItemPage(mPagePanel,mCart));
        		mPagePanel.revalidate();
        		mPagePanel.repaint();
        	}
        });

        JButton bt5 = new JButton(
                "장바구니의 항목 수량 줄이기",
                resizeIcon("/Users/sujin/eclipse-workspace/BookMarketSwing/src/images/5.png"));

        JButton bt6 = new JButton(
                "장바구니의 항목 삭제하기",
                resizeIcon("/Users/sujin/eclipse-workspace/BookMarketSwing/src/images/6.png"));
        bt6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(mCart.mCartCount==0) {
        			JOptionPane.showMessageDialog(bt3,"장바구니에 항목이 없습니다","장바구니 비우기",JOptionPane.ERROR_MESSAGE);
        		}
        		else {
        			mPagePanel.removeAll();
        			CartItemListPage cartList=new CartItemListPage(mPagePanel,mCart);
        			if(mCart.mCartCount==0) {
        				JOptionPane.showMessageDialog(bt6, "장바구니에 항목이 없습니다");
        			}
        			else if(cartList.mSelectRow==-1) {
        				JOptionPane.showMessageDialog(bt6,"장바구니에서 삭제할 항목을 선택하세요");
        			}
        			else {
        				mCart.removeCart(cartList.mSelectRow);
        				cartList.mSelectRow=-1;
        			}}
        		mPagePanel.add("장바구니의 항목 삭제하기",new CartItemListPage(mPagePanel,mCart));
        		mPagePanel.revalidate();
        		mPagePanel.repaint();
        	}
        });

        JButton bt7 = new JButton(
                "영수증 표시하기",
                resizeIcon("/Users/sujin/eclipse-workspace/BookMarketSwing/src/images/7.png"));
        bt7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(mCart.mCartCount==0) {
        			JOptionPane.showMessageDialog(bt7,"장바구니에 항목이 없습니다","주문처리",JOptionPane.ERROR_MESSAGE );
        		}
        		else {
        			mPagePanel.removeAll();
        			mPagePanel.add("주문 배송지",new CartShippingPage(mPagePanel,mCart));
        			mPagePanel.revalidate();
        			mPagePanel.repaint();
        		}
        	}
        });

        JButton bt8 = new JButton(
                "종료",
                resizeIcon("/Users/sujin/eclipse-workspace/BookMarketSwing/src/images/8.png"));
        bt8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		int select=JOptionPane.showConfirmDialog(bt8, "쇼핑몰을 종료하겠습니까?");
        		if(select==0) {
        			System.exit(1);
        		}
        	}
        });
        
        JButton bt9 = new JButton( //로그인 화면 미출력으로 AI로 틀 잡은 후 작성
                "관리자 로그인",
                resizeIcon("/Users/sujin/eclipse-workspace/BookMarketSwing/src/images/9.png"));

        bt9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                JOptionPane.showMessageDialog(null, "관리자 버튼 클릭");

                AdminLoginDialog adminDialog =
                        new AdminLoginDialog(MainWindow.this, "관리자 로그인");

                adminDialog.setVisible(true);

                System.out.println("로그인 결과 = " + adminDialog.isLogin);

                if(adminDialog.isLogin) {
                    mPagePanel.removeAll();
                    mPagePanel.add(new AdminPage(mPagePanel));
                    mPagePanel.revalidate();
                    mPagePanel.repaint();
                }
            }
        });
        

        JButton[] buttons = {
                bt1, bt2, bt3, bt4,
                bt5, bt6, bt7, bt8,bt9
        };

        for (JButton btn : buttons) { //AI사용
            btn.setFont(ft);
            btn.setHorizontalAlignment(SwingConstants.LEFT);
            mMenuPanel.add(btn);
        }
        
    }
  }

