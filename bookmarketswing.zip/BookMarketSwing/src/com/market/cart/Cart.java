// 장바구니 정보 관 클래스(CartInterface 구현)
package com.market.cart;
import java.util.ArrayList;


import com.market.bookitem.Book;

public class Cart implements CartInterface {
	static final int NUM_BOOK=3;
	//public CartItem[] mCartItem= new CartItem[NUM_BOOK];
	//public static int mCartCount=0;
	public ArrayList<CartItem> mCartItem =new ArrayList<CartItem>();
	public static int mCartCount=0;
	public Cart() {
	
	}
	// 도서 목록 출력
	public void printBookList(Book[]booklist) {
		for(int i=0;i<booklist.length;i++) {
			System.out.print(booklist[i].getBookId()+"|");
			System.out.print(booklist[i].getName()+"|");
			System.out.print(booklist[i].getUnitPrice()+"|");
			System.out.print(booklist[i].getAuthor()+"|");
			System.out.print(booklist[i].getDescription()+"|");
			System.out.print(booklist[i].getCategory()+"|");
			System.out.print(booklist[i].getReleaseDate());
			System.out.println();
		}
	}
	// 장바구니 상품 추가
	public void insertBook(Book book) {
		mCartItem.add(new CartItem(book));
	}
	// 장바구니 전체 삭제
	public void deleteBook() {
		mCartItem.clear();
		mCartCount=0;
	}
	// 장바구니 목록 출력
	public void printCart() {
		System.out.println("장바구니 상품 목록:");
		System.out.println("**************************************");
		System.out.println("   도서ID\t|    수량\t|   합계");
		for(int i=0;i<mCartCount;i++){
			System.out.println("   "+mCartItem.get(i).getBookID()+"\t|");
			System.out.println("   "+mCartItem.get(i).getQuantity()+"\t|");
			System.out.println("   "+mCartItem.get(i).getTotalPrice());
			System.out.println("  ");
			System.out.println("**************************************");
		}
	}
	// 같은 도서 장바구니 존재 여부 확인
	public boolean isCartInBook(String bookId) {
		boolean flag=false;
		for(int i=0;i<mCartItem.size();i++) {
			if(bookId.equals(mCartItem.get(i).getBookID())) {
				mCartItem.get(i).setQuantity(mCartItem.get(i).getQuantity()+1);
				flag=true;
				break;
			}
		}
		return flag;
	}
	// 장바구니 상품 삭제
	public void removeCart(int numId) {
		if (numId >= 0 && numId < mCartItem.size()) { 

            mCartItem.remove(numId);

            if (mCartCount > 0) {
                mCartCount--;
            }
        }
	}
	public ArrayList<CartItem> getmCartItem() {
		return mCartItem;
	}
	public void setmCartItem(ArrayList<CartItem> mCartItem) {
		this.mCartItem = mCartItem;
	}
	

}
