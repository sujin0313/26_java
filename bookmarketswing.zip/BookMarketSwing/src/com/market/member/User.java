// 사용자 정보 관리 클래스(Person 상속)
package com.market.member;

// 이름, 연락처 초기화
public class User extends Person {
	public User(String name,int phone) {
		super(name,phone);
	}
	// 이름, 연락처 주소 초기화
	public User(String name,int phone,String addr) {
		super(name, phone,addr);
	}

}
