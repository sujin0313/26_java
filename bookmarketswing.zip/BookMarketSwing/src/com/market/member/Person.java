//사람 정보 저장 클래스(부모) - 사용자, 관리자 정보 관리
package com.market.member;
public class  Person {
	String name;
	int phone;
	String addr;
	// 이름, 연락처 초기화
	public Person(String name,int phone) {
		this.name=name;
		this.phone=phone;	
	}
	// 이름, 연락처, 주소 초기화
	public Person(String name,int phone,String addr) {
		this.name=name;
		this.phone=phone;
		this.addr=addr;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
}
