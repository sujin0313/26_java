// 관리자 정보 관리 클래스(Person 클래스 상속)
package com.market.member;

public class Admin extends Person {
	private String id="admin";
	private String passwd="1234";
	public Admin(String name,int phone) {
		super(name,phone);	
	}
	public String getId() {
		return id;
	}
	public String getPasswd(){
		return passwd;
	}
}


