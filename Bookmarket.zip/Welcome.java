
import java.util.Scanner;
public class Welcome {
	public static void menuGuestInfo(String name, int mobile) {
		System.out.println("현재 고객 정보:");
		System.out.println("이름"+mUser.getName()+"연락처"+mUser.getPhone());
	}
	public static void menuCartltemList() {
		System.out.println("2.장바구니 상품 목록 보기");
	}
	public static void menuCartClear() {
		System.out.println("3.장바구니 비우기");
	}
	public static void menuCarAddltem() {
		System.out.println("4.장바구니 항목 추가하기");
	}
	public static void menuCartRemoveltemCount() {
		System.out.println("5.장바구니 항목 수량 줄이기");
	}
	public static void menuCartRemoveltem() {
		System.out.println("6.장바구니 항목 삭제하기");
	}
	public static void menuCartBill() {
		System.out.println("7.영수증 표시하기");
	}
	public static void menuExit() {
		System.out.println("8.종료");
	}
	public static void menuAdminLogin() {
		System.out.print("관리자 정보를 입력하세요");
		Scanner input=new Scanner(System.in);
		System.out.print("아이디:");
		String adminId=input.next();
		System.out.print("비밀번호: ");
		String adminPw = input.next();
		Admin admin=new Admin("관리자",15881588);
		if(admin.getId().equals(adminId) && admin.getPasswd().equals(adminPw)) {
			System.out.println("이름 " + admin.getName() + " 연락처 " + admin.getPhone());
		    System.out.println("아이디 " + admin.getId() + " 비밀번호 " + admin.getPasswd());
		    } else {
		        System.out.println("로그인 실패");
		    }
	}
	
	public static void menuIntroduction() {
		System.out.println("**************************************");
		System.out.println("1. 고객 정보 확인하기\t\t4.바구에 항목 추가하기");
		System.out.println("2. 장바구니상품 목록 보기 \t5.장바구니 항목 수량 줄이기");
		System.out.println("3. 장바구니 비우기 \t\t6.장바구니 항목 추가하기");
		System.out.println("7. 영수증 표시하기 \t\t8.종료");
		System.out.println("9.관리자 로그인");
		System.out.println("**************************************");
	}
	static User mUser;
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("당신의 이름을 입력하세요:");
		String userName = input.next();
		System.out.print("연락처를 입력하세요:");
		int userMobile = input.nextInt();
		mUser=new User(userName,userMobile);
		String greeting = "Welcome to Shopping Mall";
		String tagline  = "Welcome to Book Market";
		boolean quit = false;
		while (!quit) {
			System.out.println("정수 2개를 선택해주세요.");
			System.out.println("**************************************");
			System.out.println("\t"+greeting);
			System.out.println("\t"+tagline);
			menuIntroduction();
			System.out.println("메뉴를 선택해주세요");
			int n = input.nextInt();
			if(n<1 || n>9) {
				System.out.println("1부터 9까지의 숫자를 입력하세요:");
			}else {
					switch(n) {
					case 1:
						/*System.out.println("현재 고객 정보:");
						System.out.println("이름"+userName+"연락처"+userMobile);*/
						menuGuestInfo(userName,userMobile);
						break;
					case 2:
						//System.out.println("2.장바구니 상품 목록 보기");
						menuCartltemList();
						break;
					case 3:
						//System.out.println("3.장바구니 비우기");
						menuCartClear();
						break;
					case 4:
						//System.out.println("4.장바구니에 항목 추가하기:");
						menuCarAddltem();
						break;
					case 5:
						//System.out.println("5.장바구니의 항목 수량 줄이기");
						menuCartRemoveltem();
						break;
					case 6:
						//System.out.println("6.장바구니의 항목 삭제하기");
						menuCartRemoveltem();
						break;
					case 7:
						//System.out.println("7.영수증 표시하기");
						menuCartBill() ;
						break;
					case 8:
						//System.out.println("8.종료");
						menuExit();
						quit = true;
						break;
					case 9:
						menuAdminLogin();
						break;
					}
				}
			
		}

 } }
 
