
public class  Person {
	String name;
	int phone;
	String addr;
	public Person(String name,int phone) {
		this.name=name;
		this.phone=phone;	
	}
	public Person(String name,int phone,String addr) {
		this.name=name;
		this.phone=phone;
		this.addr=addr;
	}
	public String getName() {
		return name;
	}
	public int getPhone() {
		return phone;
	}

	
}
