
public class User extends Person {
	public User(String name,int phone) {
		super(name,phone);
	}
	public User(String name,int phone,String addr) {
		super(name, phone,addr);
	}

}
