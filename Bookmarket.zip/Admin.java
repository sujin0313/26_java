
public class Admin extends Person {
	private String id="admin";
	private String passwd="1234";
	public Admin(String name,int phone) {
		super(name,phone);	
	}
	public String getId() {
		return id;
	}
	public String getPasswd(){
		return passwd;
	}
}


