package day11;

public class SamsungPhone implements PhoneInterface{
	public static void main(String[] args) {
		SamsungPhone sp=new SamsungPhone();
		sp.sandCall();
		sp.receiveCall();
		PhoneInterface pi=new SamsungPhone();
	}

	
	public void sandCall() {
		System.out.println("띠리리리링");
		
	}

	
	public void receiveCall() {
		System.out.println("전화가 왔습니다.");		
	}

}
