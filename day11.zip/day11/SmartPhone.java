package day11;

public class SmartPhone extends Calc implements PhoneInterface {
	

	public static void main(String[] args) {
		SmartPhone sp=new SmartPhone();
		sp.sandCall();
		sp.receiveCall();
		System.out.println("3+5="+sp.calculate(3, 5));
		System.out.println(sp.toString());
	}

	@Override
	public void sandCall() {
		System.out.println("따르릉따르릉");		
	}

	@Override
	public void receiveCall() {
		System.out.println("전화왔어요");
	}
	public String toString() {
		return "스마트폰입니다.";
	}
}
