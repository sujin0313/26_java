package day11;

public interface PhoneInterface {
	//상수
	final int TIMEOUT = 10000;
	void sandCall();
	void receiveCall();
	default void printLogo() {
		System.out.println("**Phone**");
	}
	
	//추상 메소드
}



