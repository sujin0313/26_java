package day11;
import java.util.Random;
public class Lotto {
	
	public static void main(String[] args) {
		Random random=new Random();
		//int n[]=new int[6];
		int n=0;
		for(int i=0;i<=6;i++) {
			n=random.nextInt(45)+1;
			System.out.println(n);
			}
		
	}

}
