package day11;
class Point{
	//정보은닉
	private int x,y;
	public int getX() {
		return x;
	}
	public Point(int x,int y) {
		this.x=x;
		this.y=y;
	}
	public int getx() {
		return x;
	}
	public int gety() {
		return y;
	}
	public void setx(int x) {
		this.x=x;
	}
	public void sety(int y) {
		this.y=y;
	}
	public String toString() {
		return "Point("+x+","+y+")";
	}
	
}
public class PointTest {

	public static void main(String[] args) {
		Point point =new Point(300,500);
		System.out.println(point.toString());
	}

}

