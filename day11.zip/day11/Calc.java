package day11;

public class Calc {

	public int calculate(int x,int y) {
		return x+y;
	}

}
