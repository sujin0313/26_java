package day05;

public class Array04 {

	public static void main(String[] args) {
		String str[] = {"사과","바나나","귤","복숭아"};
		for(int i=0;i<6;i++) {
			System.out.println(str[i]);
		}
	}

}
