package day05;
import java.util.Scanner;
public class Array01 {

	public static void main(String[] args) {
		//1차원 배열 선언
		int intArray[];
		//배열 생성
		intArray = new int [5];
		int intMax;
		Scanner scan = new Scanner(System.in);
		intMax = 0;
		System.out.println("양수 5개를 입력하세요");
		for(int i=0;i<5;i++) {
			intArray[i] = scan.nextInt();
			if(intArray[i]>intMax)
				intMax = intArray[i];
		}
		System.out.println("가장 큰 수"+intMax+"입니다");
		
	}

}
