
public class  Person {
	String name;
	int phone;
	String addr;
	public Person(String name,int phone) {
		this.name=name;
		this.phone=phone;	
	}
	public Person(String name,int phone,String addr) {
		this.name=name;
		this.phone=phone;
		this.addr=addr;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	
	
}
