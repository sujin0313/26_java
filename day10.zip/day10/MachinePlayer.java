package day10;

class MachinePlayer extends Player {

    public MachinePlayer(String name) {
        super(name);
    }

    public String turn() {
        return shape[(int)(Math.random() * 3)];
    }
}



