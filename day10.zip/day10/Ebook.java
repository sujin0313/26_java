package day10;
class Book{
	private String title;
	public Book(String title) {this.title=title;}
	protected String getTitle() {return title;}
}
class Ebook extends Book{
	int inch;
	public Ebook(String title,int inch) {
		super(title);
		this.inch=inch;
}
	public void printInfo() {
		System.out.println(super.getTitle()+this.inch+"인치 전자책입니다.");
	}
	public void text2speech(int page) {
		System.out.println(page+"페이지의 텍스트를 음성으로 출력합니다.");
	}

public static void main(String[] args) {
		Ebook javaBook=new Ebook("자바에센셜-전자책",14);
		javaBook.printInfo();
		javaBook.text2speech(3);
}
}


