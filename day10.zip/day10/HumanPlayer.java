package day10;

import java.util.Scanner;

class HumanPlayer extends Player {

    Scanner sc = new Scanner(System.in);

    public HumanPlayer(String name) {
        super(name);
    }

    public String turn() {
        System.out.print("가위, 바위, 보 입력 >> ");
        return sc.next();
    }
}
