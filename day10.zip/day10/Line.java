package day10;

public class Line extends Shape {
	public void draw() {
		System.out.println("선을 그리다");
	}

	

}
