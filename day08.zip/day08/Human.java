package day08;

public class Human extends Animal{

	private String addr;
	public Human() {}
	public Human(String name,int age) {
		super(name,age);
	}
	
	public String getAddr() {
		return addr;
	}
	public void setAddr(String adde) {
		this.addr=addr;
	}
	

}
