package day08;

public class Animal {
	String name;
	int age;
	public Animal() {}
	public Animal(String name,int age) {
		this.name=name;
		this.age=age;
	}
	public void setName(String name) {//멤버값을 저장하는 setter 메소드
		this.name=name;
	}
	public void setAge(int age) {
		this.age=age;
	}
	public String getName() {//속성값을 확인하는 용도의 getter메소드
		return name;
		
	}
	public int getAge() {
		return age;
	}
	
	public void eat() {}
	public void sleep() {}
	public void love() {}
	

}
