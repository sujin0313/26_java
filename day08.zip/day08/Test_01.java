package day08;
import java.util.Scanner;
class Grade{
	 String name;
	 int java, web, os;

public Grade(String name, int java, int web, int os) {
	this.name = name;
	this.java = java;
	this.web = web;
	this.os=os;
}
public String getName() {
    return name;
}

public int getAverage() {
    return (java + web + os)/3;
}}
public class Test_01 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("이름, 자바,웹프로그래밍, 운영체제 순으로 점수 입력:");
		String name=sc.next();
		int java=sc.nextInt();
		int web=sc.nextInt();
		int os=sc.nextInt();
		Grade st=new Grade(name,java,web,os);
		System.out.print(st.getName()+ "의 평균은" +st.getAverage());
		sc.close();	
	}
}


