package day08;

public class AnimalTest {

	public static void main(String[] args) {
		Animal cat=new Animal();
		Human hong=new Human();
		hong.setName("홍길동");
		hong.setAge(25);
		hong.setAddr("대전동구용운동");
		
		//cat.name="뽀삐";
		cat.setName("뽀삐");
		//cat.age=10;
		cat.setAge(10);
		System.out.println(cat.age);
		System.out.println(hong.getName());
		System.out.println(hong.getAddr());
	}

}
