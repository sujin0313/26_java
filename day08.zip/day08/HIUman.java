package day08;

public class HIUman extends Animal{

	private String addr;
	
	public String getAddr() {
		return addr;
	}
	public void setAddr(String adde) {
		this.addr=addr;
	}
	

}
