package day07;
class Circle{
	String name;
	int r;
	
	public Circle() {
		this(0,"");
	}
	public Circle(int r) {
		this(r,"불고기피자");
	}
	public Circle(int r,String name) {
		this.r=r;
		this.name=name;
	}
	public double getarea() {
		return 3.14*r*r;
	}
}

public class Pizza {

	public static void main(String[] args) {
		Circle pizza,pizza2;
		pizza = new Circle();
		pizza2=new Circle(10,"치즈피자");
		//pizza.r=10;
		//pizza.name="피자";
		double area = pizza.getarea();
		System.out.println(pizza.name+"의 면적"+area);
	    System.out.println(pizza2.name);
		//레퍼런스 변수 donut 선언
		//Circle 객체 생성
		//도넛 반지름 5
		//도넛 이름 자바 도넛
		//도넛 면적 계산하여 출력
		
	}

}
