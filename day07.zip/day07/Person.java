package day07;

public class Person {
		// 필드(변수)
		public String name;
		public int age;
		public char abc;
		///////////////////////////////
		private String addr;
		//////////////////////////////
		/// 
		//기본 생성자 정의: 클래스 이름과 동일한 메소드, 객체 생성 시 호출
		//생성자 역할:필드(변수 초기화) 시험문제
		public Person() {
			name = "홍길동";
			age = 20;
			abc = 'A';
			System.out.println("객체가 생성됨");
			
		}
		public static String getName() {
			return naame;
		}
		//메소드
		public void 밥먹기() {
			System.out.println("밥먹다.");
		}
		public void 운동하기(String s) {
			System.out.println(s+"종목을 운동합니다");
		}
}
