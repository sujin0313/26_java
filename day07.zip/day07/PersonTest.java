package day07;

public class PersonTest {

	public static void main(String[] args) {
		//person 객체 생성하기
		Person hong = new Person();//생성자 함수(디퐅트 생성자)
		//hong.name = "홍길동";
		//hong.age = 20;
		//hong.abc = 'A';
		hong.밥먹기();
		hong.운동하기("헬스");
		hong,addr="대전 용구 용운동";
		System.out.println(hong.getName());//스텍틱 메소드 호출은 클래스 이름으로 ㅈㄱ접 접
	}

}
