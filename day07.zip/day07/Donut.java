package day07;
class Circle{
	String name;
	int r;
	
	public Circle() {
		r=10;
		name="";
	}
	public Circle(int re,String n) {
		r=re;
		name=n;
	}
	public double getarea() {
		return 3.14*r*r;
	}
}
public class Donut {
	public static void main(String[] args) {
		Circle Donut;
		Donut = new Circle();

		//Donut.r=5;
		//Donut.name="자바도넛";
		double area = Donut.getarea();
		System.out.println(Donut.name+"의 면적"+area);
		//레퍼런스 변수 donut 선언
		//Circle 객체 생성
		//도넛 반지름 5
		//도넛 이름 자바 도넛
		//도넛 면적 계산하여 출력
		
	}

}
