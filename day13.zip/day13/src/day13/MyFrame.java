package day13;
import javax.swing.*;
public class MyFrame {

	public static void main(String[] args) {
		JFrame jf = new JFrame();
		jf.setSize(300,300);
		jf.setTitle("300X300 사이즈의 프레임");
		jf.setVisible(true);
		
		JButton jbtn1=new JButton("확인");
		JButton jbtn2=new JButton();
		jbtn2.setText("취소");
		
		//jf.add(jbtn1);
		//jf.add(jbtn2);
		JPanel jp=new JPanel();
		jp.add(jbtn1);
		jp.add(jbtn2);
		
		jf.add(jp);
		
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//jf.setVisible(true);
		//jf.pack();
				
	}

}
