package day13;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class MyActionListener implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {

        JButton btn = (JButton) e.getSource();

        String text = btn.getText();

        if (text.equals("add")) {
            System.out.println("더하기 버튼이 클릭 됨");
        } 
        else if (text.equals("sub")) {
            System.out.println("빼기 버튼 클릭 됨");
        } 
        else if (text.equals("mul")) {
            System.out.println("곱하기 버튼 클릭 됨");
        } 
        else if (text.equals("div")) {
            System.out.println("나누기 버튼 클릭 됨");
        } 
        else if (text.equals("center")) {
            System.out.println("계산기 버튼 클릭 됨");
        }
    }
}
