package day13;

import java.awt.BorderLayout;
import javax.swing.*;

public class BoderLayout extends JFrame {

    JButton btn1, btn2, btn3, btn4, btn5;

    public BoderLayout() {
        setSize(250, 250);
        setTitle("세번째 프레임");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        btn1 = new JButton("add");
        btn2 = new JButton("sub");
        btn3 = new JButton("mul");
        btn4 = new JButton("div");
        btn5 = new JButton("center");

        MyActionListener listener = new MyActionListener();

        btn1.addActionListener(listener);
        btn2.addActionListener(listener);
        btn3.addActionListener(listener);
        btn4.addActionListener(listener);
        btn5.addActionListener(listener);

        add(btn1, BorderLayout.NORTH);
        add(btn2, BorderLayout.SOUTH);
        add(btn3, BorderLayout.EAST);
        add(btn4, BorderLayout.WEST);
        add(btn5, BorderLayout.CENTER);

        setVisible(true);
    }

    public static void main(String[] args) {
        new BoderLayout();
    }
}