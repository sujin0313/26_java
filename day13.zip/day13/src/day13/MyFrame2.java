package day13;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.*;
public class MyFrame2 extends JFrame{
	public MyFrame2() {
		this.setTitle("나만의 프레임 생성");
		setSize(300,300);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container contain = getContentPane();
		contain.setBackground(Color.orange);
		contain.setLayout(new FlowLayout());
		
		JButton btn1=new JButton("확인");
		JButton btn2=new JButton("취소");
		JButton btn3=new JButton("무시");
		
		contain.add(btn1);
		contain.add(btn2);
		contain.add(btn3);
		
		}
	public static void main(String[] args) {
		MyFrame2 mf2 = new MyFrame2();
		//mf2.setSize(300,300);
		//mf2.setTitle("300X300 사이즈의 프레임");
		//mf2.setVisible(true);
		
		//JButton jbtn1=new JButton("확인");
		//JButton jbtn2=new JButton();
		//jbtn2.setText("취소");
		
		//jf.add(jbtn1);
		//jf.add(jbtn2);
		//JPanel jp=new JPanel();
		//jp.add(jbtn1);
		//jp.add(jbtn2);
		
		//mf2.add(jp);
		
		//mf2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//jf.setVisible(true);
		//jf.pack();
				
	}

}
