//장바구니 기능 정의 인테페이스(Cart 클래스 구현 기능 선언)
package com.market.cart;
import com.market.bookitem.Book;
public interface CartInterface {
	void printBookList(Book[] p);
	boolean isCartInBook(String id);
	void insertBook(Book p);
	void removeCart(int numId);
	void deleteBook();
}
