package day03;
import java.util.Scanner;
public class Ex03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("정수 입력:");
		int num = sc.nextInt();
		int n = num % 2; //짝홀 판단 식
		String result = (n == 0) ? "짝수":"홀수"; //삼항연산자
		
		System.out.println(result);
		
	}

}
