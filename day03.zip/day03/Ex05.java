package day03;
import java.util.Scanner;
public class Ex05 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("점수 입력:");
		int num = scan.nextInt();
		//70이상=합격,아니면 불합격
		if(num>=70) {
			//70이상일때 출력
			System.out.println("합격");
			
		}else {
			System.out.println("불합격");
		}
	}
}
