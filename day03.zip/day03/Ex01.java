package day03;
//import(클래스 전에 작성해야함)
import java.util.Scanner;

public class Ex01 {

	public static void main(String[] args) {
		int age; //변수 선언
		String name = new String();
		//변수 초기화
		age = 21;
		name = "서수진";
		
		//Scanner객체 생성
		Scanner scan = new Scanner(System.in);
		System.out.println("나이 입력:");
		age = scan.nextInt();
		System.out.println("이름 입력:");
		name = scan.next();
		double height;
		System.out.println("키 입력:");
		height = scan.nextDouble();
		String city = new String();
		System.out.println("주소 입력:");
		city = scan.next();
		Boolean single;
		System.out.println("독신 입력:");
		single = scan.nextBoolean();
		System.out.println("나이:"+age);
		System.out.println("이름:"+name);
		System.out.println("키:"+height);
		System.out.println("주소:"+city);
		System.out.println("독신여부:"+single);	
	}

}
