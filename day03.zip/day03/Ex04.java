package day03;
import java.util.Scanner;
public class Ex04 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("숫자 입력:");
		int num = scan.nextInt();
		//짝수=짝수,아니면 홀수
		if(num%2==0) {
			//참일때 실행
			System.out.println("짝수임");
			
		}else {
			System.out.println("홀수임");
		}
	}

}
