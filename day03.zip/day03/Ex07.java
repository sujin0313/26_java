package day03;
import java.util.Scanner;
public class Ex07 {

	public static void main(String[] args) {
		char grade;
		Scanner scanner = new Scanner(System.in);
		System.out.print("점수 입력(0-100): ");
		int score = scanner.nextInt();
		System.out.print("학년 입력: ");
		int year = scanner.nextInt();
		if(score >= 90)
		   grade = 'A';
		else if(score >= 80)
			grade= 'B'; 
		else if(score >= 70)
			grade= 'C';
		else if(score >= 60)
			grade= 'D';
		else
			grade = 'F';
		System.out.print("점수"+grade+"이다");
		scanner.close();
			
	}
}
