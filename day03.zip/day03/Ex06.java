package day03;
import java.util.Scanner;
public class Ex06 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		//id,pwd 초기화
		String id="seo",pwd="1234";
		System.out.println("id 입력:");
		String myId = scan.next();
		System.out.println("pwd 입력:");
		String myPwd = scan.next();
		
		if((myId.equals(id)) && (myPwd.equals(pwd))) {
			System.out.println("로그인 성공");
			
		}else {
			System.out.println("로그인 실패");
		}
	}
}
