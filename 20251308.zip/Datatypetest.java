package day02;

public class Datatypetest {

	public static void main(String[] args) {
		//1.기본명 변수 선언
		boolean isTrue;
		int age;
		double height,weight;
		
		//2.변수 초기화
		isTrue = false;
		age = 21;
		height = 190.1;
		weight = 90;
		
		//2.레퍼러스형 - 3개(배열, 클래스, 인터페이스)
		String name = "서수진";
		//name = "서수진";
		String s = new String("홍길동");//본래 레퍼런스 형태
		String addr = "대학로 50번길";
		
		Datatypetest dtt = new Datatypetest();
		
		//3.변수 값 출력
		System.out.println(isTrue);
		System.out.println("나이:"+age);
		System.out.println("키:"+height);
		System.out.println("몸무게:"+weight);
		System.out.println("이름:"+s);
		System.out.println("주소:"+addr);




		
		
		
	}

}
