package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//print계열 사용해서 자바로 하고 싶은 것 작성해서 출력
		System.out.println("자바로 하고 싶은 것:");
		System.out.println("1.자바 사용하여 간단한 개인 프로젝트 시도");
		System.out.println("2.자바 사용하여 웹사이트 제작 시도");
		System.out.println("3.자바 개념 완벽 숙지");
		
	}

}