package day02;

public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//System.out.println("hello java");
	//System.out.println("seosujin");
	System.out.print("반갑습니다. 열심히 java 공부해요.\n줄 바꿈.");
	System.out.print("반갑습니다. 열심히 java 공부해요.\n줄 바꿈.");
	//System.out.println("정보보안학과"); //출력 함수 기본꼴
	//println:자동줄바꿈&print:자동x
	
	}
}
