package day06;
import java.util.Scanner;
public class Method03 {
	//2개의 정수와 1개의 문자열 입력, 사칙연산 수행 계산기 메소드 add(),sub(),mul(),div()
	//정의
	//문자열이 + = add, - = sub, *  = mul, / = div
	public static int add(int a, int b,String s) {
		return a+b;
		
	}
	public static int sub(int a, int b, String s) {
		return a-b;
		
	}
	public static int mul(int a, int b,String s) {
		return a*b;
		
	}
	public static int div(int a, int b,String s) {
		return a/b;
		
	}
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int a,b;
		String s;
		System.out.print("정수 1 입력:");
		a=sc.nextInt();
		System.out.print("정수 2 입력:");
		b=sc.nextInt();
		System.out.print("연산 입력:");
		s=sc.next();
		
		switch(s) {
		case "+":
			System.out.println(a+"+"+b+"="+add(a,b,s));
			break;
		case "-":
			System.out.println(a+"-"+b+"="+sub(a,b,s));
			break;
		case "*":
			System.out.println(a+"*"+b+"="+mul(a,b,s));
			break;
		case "/":
			System.out.println(a+"/"+b+"="+div(a,b,s));
			break;
		default:
			break;
			}
	}

}
