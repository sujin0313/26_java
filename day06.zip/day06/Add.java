package day06;
/*import java.util.Scanner;
public class Add {

	public static void main(String[] args) {
		// 두개의 정수 입력,합 결과 출력
		Scanner sc=new Scanner(System.in);
		System.out.println("정수 입력:");
		int i=sc.nextInt();
		System.out.println("정수 입력:");
		int j=sc.nextInt();
		int sum=i+j;
		System.out.println("합:"+sum);
		sc.close();
	}

}*/
import java.util.Scanner;
public class Add {

	public static void main(String[] args) {
		// 두개의 정수 입력,합 결과 출력
		double num1,num2,num3;
		Scanner sc=new Scanner(System.in);
		System.out.println("실수 입력:");
	    num1=sc.nextDouble();
		System.out.println("실수 입력:");
		num2=sc.nextInt();
		num3=num1*num2;
		System.out.println("곱:"+num3);
		sc.close();
	}

}