package day04;
import java.util.Scanner;
public class OpenChallenge {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("가위 위 보:");
		String user1 = sc.next();
		System.out.println("철수>>"+user1);
		String user2 = sc.next();
		System.out.println("영희>>"+user2);
		if(user1.equals("가위")) {
		    if(user2.equals("가위")){
		        System.out.println("비겼습니다");
		    }else if(user2.equals("바위")) {
		        System.out.println("철수 짐");
		    }else {
		        System.out.println("철수가 이김");
		    }

		}else if(user1.equals("바위")) {
		    if(user2.equals("바위")){
		        System.out.println("비겼습니다");
		    }else if(user2.equals("보")) {
		        System.out.println("철수 짐");
		    }else {
		        System.out.println("철수가 이김");
		    }

		}else if(user1.equals("보")) {
		    if(user2.equals("보")){
		        System.out.println("비겼습니다");
		    }else if(user2.equals("가위")) {
		        System.out.println("철수 짐");
		    }else {
		        System.out.println("철수가 이김");
		    }
}
		}
	}

