package day04;
import java.util.Scanner;
public class Test03 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int balance = 10000; //교통카드 잔액
		System.out.println("나이 입력:");
		int age = scanner.nextInt(); //정수입력
		if(age>=19) {
			balance-=1200;
			System.out.println("어른"+balance);
		}else if((age>=13)&&(age<=18)) {
			balance-=720;
			System.out.println("중고등학생"+balance);
		}else if((age>=7)&&(age<=12)) {
			balance-=450;
			System.out.println("어린이"+balance);
			scanner.close();
		}
	}

}
