package day04;

import java.util.Scanner;

public class Test01 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("나이입력:");
		int age = scan.nextInt();
		if(age<18) {
			System.out.println("청소년관람불가");
		}
	}
}
