package day04;
import java.util.Scanner;
public class Test02 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("필기시험 입력:");
		int score1 = scan.nextInt();
		System.out.println("토익점수 입력:");
		int score2 = scan.nextInt();
		if((score1>=80) && (score2>=850)) {
			System.out.println("합격");
		}else {
			System.out.println("불합격");
		}
	}
}
