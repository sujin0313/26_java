package day04;
import java.util.Scanner;
public class Test09 {
//무한반복해서 정수를 입력한 후 음수가 입력되면 무한반복을 종료하고 누적의 합을 출력하기
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("정수를 5개 입력하세요.");
		int sum=0;
		while(true) {
			int n = scan.nextInt();
			if(n<=0) {
				break; }
			else {
				sum += n; // 양수인 경우 덧셈
	 }
	}
		System.out.println("양수의 합은 " + sum);
		scan.close();
	}

}
