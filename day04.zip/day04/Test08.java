package day04;
import java.util.Scanner;
public class Test08 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("정수를 5개 입력하세요.");
		int sum=0;
		for(int i=0; i<5; i++) {
			int n = scan.nextInt();
			if(n<=0) {
				continue; }
			else {
				sum += n; // 양수인 경우 덧셈
	 }
	}
		System.out.println("양수의 합은 " + sum);
		scan.close();
	}

}
